# kelime-bulmaca-discordJS
Discord bot ile yapılmış basit kelimenin son harfiyle yeni kelime bulmaca oyunu.
